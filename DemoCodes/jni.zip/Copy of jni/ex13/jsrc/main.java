class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void generateCallbackMethodCall();

	public void callback()
	{
		System.out.println("In callback method");
	}

	public static void main(String args[])
	{
		Main m = new Main();
		m.generateCallbackMethodCall();
	}
};