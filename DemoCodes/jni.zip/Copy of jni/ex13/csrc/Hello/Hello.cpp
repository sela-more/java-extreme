// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}
JNIEXPORT void JNICALL Java_Main_generateCallbackMethodCall (JNIEnv *env, jobject obj)
{
	jclass CallbackClass = env->GetObjectClass(obj);
	jmethodID methodID = env->GetMethodID(CallbackClass, "callback", "()V");
	if (methodID == 0)
	{
		printf("Method was not found!\n");
		return;
	}
	printf("Calling a java method\n");
	env->CallVoidMethod(obj, methodID);
	printf("Java method was envoked!\n");
}

JNIEXPORT void JNICALL Java_Main_printStrings (JNIEnv *env, jclass jcls, jobjectArray JObjArr)
{
	int nLength = env->GetArrayLength(JObjArr);

	for (int i = 0 ; i < nLength ; ++i)
	{
		jstring jstr = (jstring)env->GetObjectArrayElement(JObjArr, i);
		const char *CStr = env->GetStringUTFChars(jstr, 0);
		printf("%s\n", CStr);
		env->ReleaseStringUTFChars(jstr, CStr);
	}
}
jmethodID mID = NULL;
JNIEXPORT jint JNICALL Java_Main_callGetStringLength  (JNIEnv *env, jobject obj, jstring jStr)
{
	jclass ClsStr = env->GetObjectClass(jStr);
	if (mID != NULL)
		mID = env->GetMethodID(ClsStr, "length", "()I");
	return env->CallIntMethod(jStr, mID);
	
}

