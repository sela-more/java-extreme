class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void printCharByChar(String sLine);

	public void printCharcter(char c)
	{
		System.out.print(c);
	}

	public static void main(String args[])
	{
		Main m = new Main();
		m.printCharByChar(args[0]);
	}
};