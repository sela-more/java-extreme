// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

JNIEXPORT void JNICALL Java_Main_printCharByChar (JNIEnv *env, jobject obj, jstring str)
{
	
	jclass CallbackClass = env->GetObjectClass(obj);
	jmethodID methodID = env->GetMethodID(CallbackClass, "printCharcter", "(C)V");
	if (methodID == 0)
	{
		printf("Method was not found!\n");
		return;
	}
	const jchar *StrArr = env->GetStringChars(str, 0);
	int nStrLength = env->GetStringLength(str);
	printf("Starting callbacks, There will be %d invocations:\n", nStrLength);
	for (int i = 0 ; i < nStrLength ; ++i)
		env->CallVoidMethod(obj, methodID, StrArr[i]);
	
	printf("\nString was printed, Leaving native code...!\n");
}
