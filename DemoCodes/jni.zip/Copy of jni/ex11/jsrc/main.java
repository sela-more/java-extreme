class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native boolean[] markEven(int Arr[]);

	public static void main(String args[])
	{
		int Arr[] = new int[args.length];
		for (int i = 0 ; i < Arr.length ; ++i )
		{
			Arr[i] = Integer.parseInt(args[i]);
		}

		boolean bEvenArr[] = new Main().markEven(Arr);
		for (int i = 0 ; i < bEvenArr.length ; ++i )
		{
			System.out.println(Arr[i] + " is " + (bEvenArr[i] ? " Even" : " Odd"));
		}
	}
};