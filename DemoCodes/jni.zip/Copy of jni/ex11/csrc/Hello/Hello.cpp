// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}
JNIEXPORT jbooleanArray JNICALL Java_Main_markEven (JNIEnv *env, jobject obj, jintArray jArr)
{
	int nArrSize = env->GetArrayLength(jArr);
	jbooleanArray bEvenArr = env->NewBooleanArray(nArrSize);
	jint *nNativeArray = env->GetIntArrayElements(jArr, 0);
	jboolean bFalse = 0;
	jboolean bTrue = 1;
	
	for (int i = 0 ; i < nArrSize ; ++i)
	{
		env->SetBooleanArrayRegion(bEvenArr, i, 1, (nNativeArray[i] % 2 ? &bFalse : &bTrue));
	}

	env->ReleaseIntArrayElements(jArr, nNativeArray, 0);

	return bEvenArr;
}
