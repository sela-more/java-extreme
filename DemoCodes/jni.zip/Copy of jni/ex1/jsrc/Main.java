class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void showMessageBox2();

	public static void main(String args[])
	{
		new Main().showMessageBox2();	
	}

};