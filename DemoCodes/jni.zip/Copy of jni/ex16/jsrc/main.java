class Main
{
	static {
		System.loadLibrary("Hello");
	}
	private int m_nVar1;
	private int m_nVar2;

	private int devide(int nVal1, int nVal2)
	{
		return nVal1 / nVal2;
	}
	
	private native void doCalculations();

	public static void main(String args[])
	{
		Main m = new Main();
		m.doCalculations();
	}
};