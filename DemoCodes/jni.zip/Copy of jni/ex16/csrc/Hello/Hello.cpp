// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <time.h>
#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

JNIEXPORT void JNICALL Java_Main_doCalculations  (JNIEnv *env, jobject obj)
{
	jclass cls = env->GetObjectClass(obj);
	jmethodID mID = env->GetMethodID(cls, "devide", "(II)I");
	if (mID == 0)
	{
		printf("Cannot find method signature");
		return;
	}
	for (int i = 3 ; i < 8 ; ++i)
	{
		int nVal1 = i * 2;
		int nVal2 = i - 3;
		printf("Calculating %d / %d = ", nVal1, nVal2);
		int nRetVal = env->CallIntMethod(obj, mID, nVal1, nVal2);

		if (env->ExceptionOccurred())
		{
			env->ExceptionDescribe();
			env->ExceptionClear();
		}
		else
		{
			printf(" %d\n", nRetVal);
		}
	}
}