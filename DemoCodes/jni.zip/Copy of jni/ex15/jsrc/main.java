class Main
{
	static {
		System.loadLibrary("Hello");
	}
	private int m_nVar1;
	private int m_nVar2;

	private native void swap();

	public static void main(String args[])
	{
		Main m = new Main();
		m.m_nVar1 = Integer.parseInt(args[0]);
		m.m_nVar2 = Integer.parseInt(args[1]);
		m.printVars();
		m.swap();
		m.printVars();
	}

	private void printVars()
	{
		System.out.println("Var1 = " + m_nVar1 + " Var2 = " + m_nVar2);
	}
};