// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


JNIEXPORT void JNICALL Java_Main_swap (JNIEnv *env, jobject obj)
{
	jclass cls = env->GetObjectClass(obj);
	jfieldID fi1= env->GetFieldID(cls, "m_nVar1", "I");
	jfieldID fi2 = env->GetFieldID(cls, "m_nVar2", "I");

	jint nVal1 = env->GetIntField(obj, fi1);
	jint nVal2 = env->GetIntField(obj, fi2);

	env->SetIntField(obj, fi1, nVal2);
	env->SetIntField(obj, fi2, nVal1);

}
