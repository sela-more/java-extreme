// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

JNIEXPORT jstring JNICALL Java_Main_getUserAnswer (JNIEnv *env, jobject obj, jstring sMessage)
{
	const char *nativeMessage = env->GetStringUTFChars(sMessage, 0);
	char *cRetVal;
	if (::MessageBox(NULL, nativeMessage, "Native Method RetVal", 1) == 1)
		cRetVal = "You have agreed";
	else
		cRetVal = "You have disagreed";

	jstring jRetVal = env->NewStringUTF(cRetVal);

	env->ReleaseStringUTFChars(sMessage, nativeMessage);
	env->ReleaseStringUTFChars(jRetVal, cRetVal);
	return jRetVal;
}
