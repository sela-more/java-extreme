class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native String getUserAnswer(String sMessage);

	public static void main(String args[])
	{
		System.out.println(new Main().getUserAnswer(args[0]));
	}
};