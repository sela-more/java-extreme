// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}
JNIEXPORT void JNICALL Java_Main_swapFirstTwoElements  (JNIEnv *env, jobject obj, jobjectArray jObjArr)
{
	jobject obj1 = env->GetObjectArrayElement(jObjArr, 0);
	jobject obj2 = env->GetObjectArrayElement(jObjArr, 1);
	env->SetObjectArrayElement(jObjArr, 0, obj2);
	env->SetObjectArrayElement(jObjArr, 1, obj1);
}
