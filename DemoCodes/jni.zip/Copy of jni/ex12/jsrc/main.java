class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void swapFirstTwoElements(String sArr[]);

	public static void main(String args[])
	{
		Main m = new Main();
		m.printFirstTwoElements(args);
		System.out.println("***************************************");
		m.swapFirstTwoElements(args);
		m.printFirstTwoElements(args);
	}

	private void printFirstTwoElements(String arr[])
	{
		for (int i = 0 ; i < 2 ; ++i )
		{
			System.out.println(arr[i]);
		}
	}
};