class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void printString(String sMessage);

	public static void main(String args[])
	{
		Main m = new Main();
		String str = getLongString(args[0]);
		for (int i = 0 ; i < 100000 ; ++i)
		{
			m.printString(str);
		}
	}

	private static String getLongString(String sSource)
	{
		StringBuffer sb = new StringBuffer(sSource);
		for (int i = 0 ; i < 10 ; ++i )
		{
			sb.append(sSource);
		}

		return sb.toString();
	}

};