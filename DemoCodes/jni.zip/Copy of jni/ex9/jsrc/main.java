class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native String WgetUserAnswer(String sMessage);

	public static void main(String args[])
	{
		System.out.println(new Main().WgetUserAnswer(args[0]));
	}
};