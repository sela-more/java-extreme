// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"

#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


JNIEXPORT jstring JNICALL Java_Main_WgetUserAnswer (JNIEnv *env, jobject obj, jstring sMessage)
{
	const TCHAR *nativeMessage = env->GetStringChars(sMessage, 0);
	TCHAR *cRetVal;
	if (::MessageBox(NULL, nativeMessage, L"Native Method RetVal", 1) == 1)
		cRetVal = L"You have agreed";
	else
		cRetVal = L"You have disagreed";

	jstring jRetVal = env->NewString(cRetVal, wcslen(cRetVal));

	env->ReleaseStringChars(sMessage, nativeMessage);
	env->ReleaseStringChars(jRetVal, cRetVal);
	return jRetVal;
}
