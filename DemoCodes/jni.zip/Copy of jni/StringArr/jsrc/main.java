class Main
{
	static {
		System.loadLibrary("Hello");
	}
	public native void printStrArr(String args[]);

	public static void main(String args[])
	{
		new Main().printStrArr(args);
	}	
};