class Main extends Thread
{
	static {
		System.loadLibrary("Hello");
	}

	private native void startWaiting();
	
	private void startExecution()
	{
		start();
		startWaiting();
	}

	public void run()
	{
		while (true)
		{
			try
			{
				Thread.sleep(1000);
			}
			catch (InterruptedException e) {}
			synchronized(this)
			{
				System.out.println("Calling notify() from withing the JVM");
				notify();
			}
		}
	}

	public static void main(String args[])
	{	
		new Main().startExecution();
	}
};