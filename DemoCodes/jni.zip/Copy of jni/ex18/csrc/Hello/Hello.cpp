// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <time.h>
#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

JNIEXPORT void JNICALL Java_Main_startWaiting (JNIEnv *env, jobject jthis)
{
	jclass cls = env->GetObjectClass(jthis);
	jmethodID mWaitID = env->GetMethodID(cls, "wait", "()V");
	//enter a synchronized block
	while (1)
	{
		env->MonitorEnter(jthis);
		printf("Native method entered wait\n");
		env->CallVoidMethod(jthis, mWaitID);
		printf("Native method left wait\n");
		env->MonitorExit(jthis);
	}

}

