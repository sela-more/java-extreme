class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native int showMessageBox();

	public static void main(String args[])
	{
		Main m = new Main();
		int nRetVal = m.showMessageBox();
		if (nRetVal == 1)
			System.out.println("You have clicked OK");
		else if (nRetVal == 2)
			System.out.println("You have clicked CANCEL");
		else 
			System.out.println("You have clicked some other button");
	}

};