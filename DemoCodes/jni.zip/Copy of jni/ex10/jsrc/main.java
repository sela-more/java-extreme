class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native int getSum(int Arr[]);

	public static void main(String args[])
	{
		int Arr[] = new int[args.length];
		for (int i = 0 ; i < Arr.length ; ++i )
		{
			Arr[i] = Integer.parseInt(args[i]);
		}

		System.out.println("The array sum is " + new Main().getSum(Arr));
	}
};