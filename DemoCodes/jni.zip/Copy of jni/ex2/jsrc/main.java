class Main
{
	static {
		System.loadLibrary("Hello");
	}

	private native void showMessageBox(int nNumOfTimes);

	public static void main(String args[])
	{
		new Main().showMessageBox(Integer.parseInt(args[0]));	
	}

};