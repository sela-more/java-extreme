// Hello.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include <time.h>
#include "Main.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}
JNIEXPORT int JNICALL Java_Main_devide (JNIEnv *env, jclass cls, jint nVal1, jint nVal2)
{
	
	if (nVal2 == 0)
	{
		jclass ExceptionCls = env->FindClass("java/lang/UnsupportedOperationException");
		if (ExceptionCls == 0)
		{
			printf("Cannot find exceptions class, terminating call\n");
			return -1;
		}
		env->ThrowNew(ExceptionCls, "Cannot devide by 0, this message comes from the native DLL");
		return -1;
	}
	return nVal1 / nVal2;
}