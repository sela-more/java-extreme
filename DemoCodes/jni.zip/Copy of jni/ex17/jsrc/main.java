class Main
{
	static {
		System.loadLibrary("Hello");
	}
	
	private static native int devide(int nVal1, int nVal2) throws UnsupportedOperationException;

	public static void main(String args[])
	{
		int nRetVal = 0;
		try
		{
			nRetVal = devide(Integer.parseInt(args[0]), Integer.parseInt(args[1]));	
		}
		catch (UnsupportedOperationException e)
		{
			System.out.println("################## ERROR ###################");
			e.printStackTrace();
			return;
		}

		System.out.println(Integer.parseInt(args[0]) + " / " + Integer.parseInt(args[1]) + " = " + nRetVal);
		
	}
};